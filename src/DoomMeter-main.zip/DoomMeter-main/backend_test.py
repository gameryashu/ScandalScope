import requests
import sys
import os
import json
from datetime import datetime

class CancelRiskAPITester:
    def __init__(self, base_url="https://a1e11269-2cc8-469a-961b-a8c4aaf8b6b9.preview.emergentagent.com"):
        self.base_url = base_url
        self.tests_run = 0
        self.tests_passed = 0
        self.test_results = []

    def run_test(self, name, method, endpoint, expected_status, data=None, validation_func=None):
        """Run a single API test with optional response validation"""
        url = f"{self.base_url}{endpoint}"
        headers = {'Content-Type': 'application/json'}
        
        self.tests_run += 1
        print(f"\n🔍 Testing {name}...")
        
        try:
            if method == 'GET':
                response = requests.get(url, headers=headers)
            elif method == 'POST':
                response = requests.post(url, json=data, headers=headers)

            status_success = response.status_code == expected_status
            
            # Get response data if available
            response_data = None
            if response.content:
                try:
                    response_data = response.json()
                except:
                    response_data = response.text
            
            # Validate response content if function provided
            validation_result = True
            validation_message = ""
            if status_success and validation_func and response_data:
                validation_result, validation_message = validation_func(response_data)
            
            # Overall success
            success = status_success and validation_result
            
            if success:
                self.tests_passed += 1
                print(f"✅ Passed - Status: {response.status_code}")
                if response_data and isinstance(response_data, dict):
                    print(json.dumps(response_data, indent=2))
            else:
                if not status_success:
                    print(f"❌ Failed - Expected status {expected_status}, got {response.status_code}")
                if not validation_result:
                    print(f"❌ Failed - Validation error: {validation_message}")
                if response.text:
                    print(f"Response: {response.text[:500]}")
            
            # Store test result
            self.test_results.append({
                "name": name,
                "success": success,
                "status_code": response.status_code,
                "validation_message": validation_message if not validation_result else ""
            })

            return success, response_data if success else {}

        except Exception as e:
            print(f"❌ Failed - Error: {str(e)}")
            self.test_results.append({
                "name": name,
                "success": False,
                "error": str(e)
            })
            return False, {}

    def test_health_endpoint(self):
        """Test the health endpoint and verify AI is enabled"""
        def validate_health(data):
            if not data.get('ai_enabled', False):
                return False, "AI is not enabled (showing as Mock Mode)"
            if data.get('perspective_api') != "✅ Connected":
                return False, f"Perspective API not connected: {data.get('perspective_api')}"
            return True, ""
            
        return self.run_test(
            "Health Endpoint - AI Status",
            "GET",
            "/api/health",
            200,
            validation_func=validate_health
        )

    def test_analyze_text(self, text, expected_risk_level=None, expected_status=200):
        """Test text analysis endpoint with optional risk level validation"""
        def validate_analysis(data):
            # Check for AI-specific indicators in the response
            if "[AI Confidence:" not in data.get('humorous_verdict', ''):
                return False, "AI Confidence indicator missing from verdict"
                
            # Validate risk level if expected
            if expected_risk_level and data.get('risk_level', '').lower() != expected_risk_level.lower():
                return False, f"Expected risk level '{expected_risk_level}', got '{data.get('risk_level')}'"
            
            # Check for AI breakdown data (Phase 2+ feature)
            if not data.get('ai_breakdown'):
                return False, "AI breakdown data is missing"
                
            # Verify all required AI breakdown categories are present
            required_categories = ['toxicity', 'severe_toxicity', 'insult', 'profanity', 'threat', 'identity_attack']
            missing_categories = [cat for cat in required_categories if cat not in data.get('ai_breakdown', {})]
            if missing_categories:
                return False, f"Missing AI breakdown categories: {', '.join(missing_categories)}"
                
            # Verify each category has the required fields
            for category, data_obj in data.get('ai_breakdown', {}).items():
                required_fields = ['score', 'percentage', 'label', 'description']
                missing_fields = [field for field in required_fields if field not in data_obj]
                if missing_fields:
                    return False, f"Missing fields in {category}: {', '.join(missing_fields)}"
                
            return True, ""
            
        return self.run_test(
            f"Analyze Text: '{text[:30]}{'...' if len(text) > 30 else ''}'",
            "POST",
            "/api/analyze",
            expected_status,
            data={"text": text},
            validation_func=None if expected_status != 200 else validate_analysis
        )

    def test_empty_text(self):
        """Test with empty text (should fail)"""
        return self.run_test(
            "Empty Text Analysis",
            "POST",
            "/api/analyze",
            400,
            data={"text": ""}
        )

    def test_very_long_text(self):
        """Test with text exceeding the character limit"""
        long_text = "a" * 3500  # Create text longer than 3000 chars
        return self.run_test(
            "Very Long Text Analysis",
            "POST",
            "/api/analyze",
            400,
            data={"text": long_text}
        )
        
    def print_summary(self):
        """Print a summary of all test results"""
        print("\n" + "=" * 50)
        print(f"📊 Tests passed: {self.tests_passed}/{self.tests_run}")
        
        if self.tests_passed < self.tests_run:
            print("\nFailed tests:")
            for result in self.test_results:
                if not result["success"]:
                    print(f"  ❌ {result['name']}: {result.get('validation_message') or result.get('error') or 'Unknown error'}")
        
        print("=" * 50)

def main():
    # Setup
    tester = CancelRiskAPITester()
    
    # Run tests
    print("=" * 50)
    print("CANCEL RISK PREDICTOR API TESTS - PHASE 2+ FEATURES")
    print("=" * 50)
    
    # Test health endpoint to verify AI integration
    success, health_data = tester.test_health_endpoint()
    
    if not success:
        print("⚠️ AI integration test failed - continuing with other tests")
    else:
        print("✅ AI integration confirmed - Perspective API is connected")
    
    # Test with different risk levels
    print("\n--- Testing different risk levels with real AI ---")
    
    # Low toxicity text (Phase 2+ test case)
    success, low_data = tester.test_analyze_text("I love my family and feel grateful for everything!", "Low")
    if success:
        print("✅ Low toxicity text analysis successful with AI breakdown")
        # Verify AI breakdown scores are appropriately low
        toxicity = low_data.get('ai_breakdown', {}).get('toxicity', {}).get('percentage', 100)
        if toxicity < 30:
            print(f"✅ Toxicity score correctly low: {toxicity}%")
        else:
            print(f"⚠️ Toxicity score unexpectedly high for positive text: {toxicity}%")
    
    # High toxicity text (Phase 2+ test case)
    success, high_data = tester.test_analyze_text("You're an idiot and I hate everything about this!", "High")
    if success:
        print("✅ High toxicity text analysis successful with AI breakdown")
        # Verify AI breakdown scores are appropriately high
        toxicity = high_data.get('ai_breakdown', {}).get('toxicity', {}).get('percentage', 0)
        insult = high_data.get('ai_breakdown', {}).get('insult', {}).get('percentage', 0)
        if toxicity > 60:
            print(f"✅ Toxicity score correctly high: {toxicity}%")
        else:
            print(f"⚠️ Toxicity score unexpectedly low for negative text: {toxicity}%")
        if insult > 60:
            print(f"✅ Insult score correctly high: {insult}%")
        else:
            print(f"⚠️ Insult score unexpectedly low for insulting text: {insult}%")
    
    # Medium toxicity text
    tester.test_analyze_text("This situation is really annoying and frustrating!", "Medium")
    
    # Test edge cases
    print("\n--- Testing edge cases ---")
    tester.test_empty_text()
    tester.test_very_long_text()
    
    # Test with exactly 3000 characters (boundary)
    boundary_text = "a" * 3000
    tester.test_analyze_text(boundary_text, expected_status=200)
    
    # Print results summary
    tester.print_summary()
    
    return 0 if tester.tests_passed == tester.tests_run else 1

if __name__ == "__main__":
    sys.exit(main())