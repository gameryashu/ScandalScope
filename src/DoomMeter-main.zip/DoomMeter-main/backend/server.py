from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional
import re
import random
import os
from googleapiclient import discovery
from dotenv import load_dotenv
import asyncio
from concurrent.futures import ThreadPoolExecutor

# Load environment variables
load_dotenv()

app = FastAPI(title="Cancel Risk Predictor API")

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize thread pool for async API calls
executor = ThreadPoolExecutor(max_workers=4)

# Request model
class TextAnalysisRequest(BaseModel):
    text: str

# Response model
class TextAnalysisResponse(BaseModel):
    toxicity_score: int
    risk_level: str
    humorous_verdict: str
    risk_factors: List[str]
    ai_breakdown: Optional[dict] = None  # New field for detailed AI scores

# Perspective API Client
class PerspectiveAnalyzer:
    def __init__(self):
        api_key = os.getenv('PERSPECTIVE_API_KEY')
        if not api_key:
            raise ValueError("PERSPECTIVE_API_KEY not found in environment variables")
        
        self.client = discovery.build(
            "commentanalyzer",
            "v1alpha1",
            developerKey=api_key,
            discoveryServiceUrl="https://commentanalyzer.googleapis.com/$discovery/rest?version=v1alpha1",
            static_discovery=False
        )
    
    async def analyze_toxicity(self, text: str) -> dict:
        """Analyze text toxicity using Perspective API"""
        try:
            loop = asyncio.get_event_loop()
            result = await loop.run_in_executor(executor, self._sync_analyze, text)
            return result
        except Exception as e:
            print(f"Perspective API Error: {str(e)}")
            # Fallback to mock analysis if API fails
            return self._fallback_analysis(text)
    
    def _sync_analyze(self, text: str) -> dict:
        """Synchronous API call to Perspective"""
        analyze_request = {
            'comment': {'text': text},
            'requestedAttributes': {
                'TOXICITY': {},
                'SEVERE_TOXICITY': {},
                'IDENTITY_ATTACK': {},
                'INSULT': {},
                'PROFANITY': {},
                'THREAT': {}
            }
        }
        
        response = self.client.comments().analyze(body=analyze_request).execute()
        return response
    
    def _fallback_analysis(self, text: str) -> dict:
        """Fallback mock analysis if Perspective API fails"""
        # Simple mock fallback
        text_lower = text.lower()
        base_score = 0.1
        
        # Basic pattern matching for fallback
        if any(word in text_lower for word in ['hate', 'stupid', 'idiot', 'kill']):
            base_score = 0.8
        elif any(word in text_lower for word in ['angry', 'mad', 'annoyed']):
            base_score = 0.5
        elif len(text) > 0 and text.isupper():
            base_score = 0.4
        
        return {
            'attributeScores': {
                'TOXICITY': {'summaryScore': {'value': base_score}},
                'SEVERE_TOXICITY': {'summaryScore': {'value': base_score * 0.7}},
                'IDENTITY_ATTACK': {'summaryScore': {'value': base_score * 0.3}},
                'INSULT': {'summaryScore': {'value': base_score * 0.6}},
                'PROFANITY': {'summaryScore': {'value': base_score * 0.4}},
                'THREAT': {'summaryScore': {'value': base_score * 0.2}}
            }
        }

# Initialize analyzer
try:
    perspective_analyzer = PerspectiveAnalyzer()
    PERSPECTIVE_ENABLED = True
    print("✅ Perspective API initialized successfully!")
except Exception as e:
    print(f"⚠️  Perspective API initialization failed: {str(e)}")
    PERSPECTIVE_ENABLED = False

# Humorous verdicts
VERDICTS = {
    "low": [
        "Your post is safer than a bubble wrap factory. You could probably tweet this from your grandma's account! 👵",
        "This text is so innocent, it makes vanilla ice cream look controversial. You're good to go! 🍦",
        "Congratulations! Your post has the scandal potential of watching paint dry. Sleep peacefully tonight. 😴",
        "This content is more harmless than a kitten wearing mittens. Your reputation remains intact. 🐱",
        "Your text is so wholesome, it could be a children's bedtime story. Zero cancel risk detected. 📚",
    ],
    "medium": [
        "Your post is walking the tightrope of controversy. Maybe run it by your mom first? 🤔",
        "This has 'spirited debate in the comments' energy. Proceed with caution, brave soul. ⚡",
        "Your text is giving me 'this could go viral for the wrong reasons' vibes. Consider editing? 📝",
        "This post is like a sneeze during a quiet moment - not terrible, but everyone will notice. 🤧",
        "You're playing with fire, but it's more like a birthday candle than a blowtorch. Handle with care. 🕯️",
        "This content is in the 'explain yourself to HR' territory. Maybe tone it down a notch? 👔",
    ],
    "high": [
        "🚨 ALERT: This post has more red flags than a Soviet parade. Maybe save it as a draft... forever.",
        "Your text is spicier than Carolina Reapers at a ghost pepper convention. RIP your mentions. 🌶️",
        "This content could start more drama than a reality TV reunion show. Are you sure about this? 📺",
        "Warning: This post might make you famous for all the wrong reasons. Consider witness protection. 🥸",
        "Your text is basically a career suicide note with extra steps. Please reconsider your life choices. ⚰️",
        "This content is so controversial, it makes pineapple on pizza debates look civilized. Danger zone! 🍕",
        "DEFCON 1: This post could get you canceled faster than a subscription you forgot about. 💳",
    ]
}

async def analyze_text_with_ai(text: str) -> TextAnalysisResponse:
    """
    Analyze text using Perspective API for real toxicity detection
    """
    try:
        # Get toxicity analysis from Perspective API
        perspective_result = await perspective_analyzer.analyze_toxicity(text)
        
        # Extract toxicity scores
        attributes = perspective_result['attributeScores']
        toxicity_raw = attributes['TOXICITY']['summaryScore']['value']
        severe_toxicity = attributes['SEVERE_TOXICITY']['summaryScore']['value'] 
        insult = attributes['INSULT']['summaryScore']['value']
        profanity = attributes['PROFANITY']['summaryScore']['value']
        threat = attributes['THREAT']['summaryScore']['value']
        identity_attack = attributes['IDENTITY_ATTACK']['summaryScore']['value']
        
        # Convert to 0-100 scale (Perspective API returns 0-1)
        toxicity_score = int(toxicity_raw * 100)
        
        # Add some randomness to make it more interesting (±5 points)
        toxicity_score += random.randint(-5, 5)
        toxicity_score = max(0, min(100, toxicity_score))
        
        # Determine risk level based on toxicity score
        if toxicity_score >= 60:
            risk_level = "High"
        elif toxicity_score >= 30:
            risk_level = "Medium"
        else:
            risk_level = "Low"
        
        # Generate risk factors based on AI analysis
        risk_factors = []
        
        if severe_toxicity > 0.5:
            risk_factors.append("🔥 Severe toxicity detected by AI")
        if insult > 0.6:
            risk_factors.append("😤 Contains insulting language")
        if profanity > 0.7:
            risk_factors.append("🤬 Profanity detected")
        if threat > 0.5:
            risk_factors.append("⚠️ Threatening language identified")
        if identity_attack > 0.5:
            risk_factors.append("🎯 Potential identity-based attack")
        if toxicity_raw > 0.8:
            risk_factors.append("☢️ Extremely high toxicity level")
        
        # Add contextual risk factors
        if len(text) > 500:
            risk_factors.append("📝 Very long text (more room for trouble)")
        if text.count('!') > 5:
            risk_factors.append("❗ Excessive exclamation marks")
        if len([c for c in text if c.isupper()]) / len(text) > 0.5:
            risk_factors.append("📢 Too much CAPS LOCK (seems aggressive)")
        
        if not risk_factors:
            risk_factors = ["✅ No significant risks detected by AI"]
        
        # Generate humorous verdict with AI score
        verdict_pool = VERDICTS[risk_level.lower()]
        base_verdict = random.choice(verdict_pool)
        
        # Add AI-powered context to verdict
        if PERSPECTIVE_ENABLED:
            ai_context = f" [AI Confidence: {int(toxicity_raw * 100)}% toxic]"
            humorous_verdict = base_verdict + ai_context
        else:
            humorous_verdict = base_verdict + " [Fallback mode - API unavailable]"
        
        # Generate detailed AI breakdown for transparency
        ai_breakdown = {
            "toxicity": {
                "score": round(toxicity_raw, 3),
                "percentage": int(toxicity_raw * 100),
                "label": "Overall Toxicity",
                "description": "How toxic or harmful the text appears"
            },
            "severe_toxicity": {
                "score": round(severe_toxicity, 3),
                "percentage": int(severe_toxicity * 100),
                "label": "Severe Toxicity",
                "description": "Extremely harmful or hateful content"
            },
            "insult": {
                "score": round(insult, 3),
                "percentage": int(insult * 100),
                "label": "Insult",
                "description": "Personal attacks or insulting language"
            },
            "profanity": {
                "score": round(profanity, 3),
                "percentage": int(profanity * 100),
                "label": "Profanity",
                "description": "Swear words or offensive language"
            },
            "threat": {
                "score": round(threat, 3),
                "percentage": int(threat * 100),
                "label": "Threat",
                "description": "Threatening or intimidating language"
            },
            "identity_attack": {
                "score": round(identity_attack, 3),
                "percentage": int(identity_attack * 100),
                "label": "Identity Attack",
                "description": "Attacks based on identity or demographics"
            }
        }
        
        return TextAnalysisResponse(
            toxicity_score=toxicity_score,
            risk_level=risk_level,
            humorous_verdict=humorous_verdict,
            risk_factors=risk_factors[:6],  # Limit to 6 most relevant factors
            ai_breakdown=ai_breakdown  # Add detailed breakdown
        )
        
    except Exception as e:
        print(f"Analysis error: {str(e)}")
        raise HTTPException(status_code=500, detail=f"AI analysis failed: {str(e)}")

@app.get("/")
async def root():
    api_status = "🤖 AI-Powered" if PERSPECTIVE_ENABLED else "🔧 Mock Mode"
    return {"message": f"Cancel Risk Predictor API is running! {api_status} 🔥"}

@app.get("/api/health")
async def health_check():
    return {
        "status": "healthy", 
        "message": "API is working properly",
        "ai_enabled": PERSPECTIVE_ENABLED,
        "perspective_api": "✅ Connected" if PERSPECTIVE_ENABLED else "❌ Fallback Mode"
    }

@app.post("/api/analyze", response_model=TextAnalysisResponse)
async def analyze_text(request: TextAnalysisRequest):
    """
    Analyze text and return cancel risk prediction using real AI
    """
    try:
        if not request.text or not request.text.strip():
            raise HTTPException(status_code=400, detail="Text cannot be empty")
        
        if len(request.text) > 3000:  # Perspective API limit
            raise HTTPException(status_code=400, detail="Text is too long (max 3000 characters)")
        
        # Perform AI-powered analysis
        result = await analyze_text_with_ai(request.text.strip())
        
        return result
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Analysis failed: {str(e)}")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8001)