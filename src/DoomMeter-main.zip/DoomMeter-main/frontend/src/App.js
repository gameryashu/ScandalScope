import React, { useState } from 'react';
import './App.css';

function App() {
  const [text, setText] = useState('');
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [showBreakdown, setShowBreakdown] = useState(false);

  // Sample texts for testing
  const sampleTexts = [
    "I love spending time with my family and being grateful for life!",
    "This politician is making some questionable decisions lately...",
    "I HATE when people disagree with me about important issues!!!",
    "Can't believe how ANGRY I am about this situation right now!",
    "Why does everyone always have to be so STUPID about everything?!",
    "Honestly, this generation is completely lost and hopeless.",
    "I'm so blessed to have amazing friends and a wonderful life! 🙏",
    "Working from home is amazing, but I miss office interactions sometimes.",
  ];

  const getRandomSample = () => {
    const randomText = sampleTexts[Math.floor(Math.random() * sampleTexts.length)];
    setText(randomText);
  };

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text).then(() => {
      alert('Copied to clipboard! 📋');
    }).catch(() => {
      alert('Failed to copy to clipboard');
    });
  };

  const shareToTwitter = () => {
    const tweetText = `I just tested my cancel risk and got ${result.toxicity_score}/100! 

"${result.humorous_verdict.split('[')[0].trim()}"

Test your own posts: ${window.location.href}

#CancelRiskPredictor #AI #SocialMedia`;
    
    const twitterUrl = `https://twitter.com/intent/tweet?text=${encodeURIComponent(tweetText)}`;
    window.open(twitterUrl, '_blank');
  };

  const copyResultLink = () => {
    const resultText = `Cancel Risk Score: ${result.toxicity_score}/100
Risk Level: ${result.risk_level}
AI Verdict: "${result.humorous_verdict}"

Test your own at: ${window.location.href}`;
    
    copyToClipboard(resultText);
  };

  const analyzeText = async () => {
    if (!text.trim()) {
      alert('Please enter some text to analyze!');
      return;
    }

    setLoading(true);
    try {
      const response = await fetch(`${process.env.REACT_APP_BACKEND_URL}/api/analyze`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ text: text }),
      });

      if (!response.ok) {
        throw new Error('Analysis failed');
      }

      const data = await response.json();
      setResult(data);
    } catch (error) {
      console.error('Error:', error);
      alert('Failed to analyze text. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const getRiskColor = (level) => {
    switch (level) {
      case 'Low': return 'text-green-600 bg-green-100';
      case 'Medium': return 'text-yellow-600 bg-yellow-100';
      case 'High': return 'text-red-600 bg-red-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getRiskEmoji = (level) => {
    switch (level) {
      case 'Low': return '😌';
      case 'Medium': return '😬';
      case 'High': return '💀';
      default: return '🤔';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900">
      {/* Header */}
      <div className="container mx-auto px-4 py-8">
        <div className="text-center mb-12">
          <h1 className="text-5xl font-bold text-white mb-4">
            Cancel Risk Predictor 🔥
          </h1>
          <p className="text-xl text-gray-300 mb-2">
            Will your post get you canceled? Let's find out! 
          </p>
          <p className="text-sm text-gray-400">
            Powered by AI humor and questionable life choices
          </p>
        </div>

        {/* Main Content */}
        <div className="max-w-4xl mx-auto">
          {/* Input Section */}
          <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-8 mb-8 border border-white/20">
            <h2 className="text-2xl font-bold text-white mb-6">
              Paste Your Potentially Problematic Post 📱
            </h2>
            
            <textarea
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="Type or paste your text here... We promise not to judge (much) 👀

Examples to try:
• 'I love spending time with my family!'
• 'This politician is making questionable decisions...'  
• 'I HATE when people disagree with me!!!'
• 'Can't believe how STUPID some people are!!!'"
              className="w-full h-40 p-4 rounded-xl bg-white/20 border border-white/30 text-white placeholder-gray-300 focus:outline-none focus:ring-2 focus:ring-purple-400 focus:border-transparent resize-none"
            />
            
            <div className="flex justify-between items-center mt-6">
              <div className="flex items-center space-x-4">
                <span className="text-gray-300 text-sm">
                  Characters: {text.length} | Words: {text.trim().split(/\s+/).filter(w => w).length}
                </span>
                <button
                  onClick={getRandomSample}
                  className="px-4 py-2 bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-600 hover:to-blue-600 text-white text-sm font-medium rounded-lg transition-all duration-300 transform hover:scale-105"
                >
                  🎲 Random Example
                </button>
              </div>
              
              <button
                onClick={analyzeText}
                disabled={loading || !text.trim()}
                className="px-8 py-3 bg-gradient-to-r from-red-500 to-pink-500 hover:from-red-600 hover:to-pink-600 disabled:from-gray-400 disabled:to-gray-500 text-white font-bold rounded-xl transition-all duration-300 transform hover:scale-105 disabled:scale-100"
              >
                {loading ? (
                  <div className="flex items-center">
                    <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                    Analyzing...
                  </div>
                ) : (
                  'Predict My Doom 🔮'
                )}
              </button>
            </div>
          </div>

          {/* Results Section */}
          {result && (
            <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-8 border border-white/20 animate-fadeIn">
              <h2 className="text-2xl font-bold text-white mb-6">
                The Verdict Is In... ⚖️
              </h2>
              
              {/* Risk Score */}
              <div className="grid md:grid-cols-2 gap-6 mb-8">
                <div className="bg-white/20 rounded-xl p-6 text-center">
                  <h3 className="text-lg font-semibold text-white mb-4">Cancel Risk Score</h3>
                  <div className="relative">
                    <div className="text-6xl font-bold text-white mb-2">
                      {result.toxicity_score}
                    </div>
                    <div className="text-sm text-gray-300">out of 100</div>
                    {/* Risk Meter */}
                    <div className="w-full bg-gray-700 rounded-full h-3 mt-4">
                      <div 
                        className={`h-3 rounded-full transition-all duration-1000 ${
                          result.toxicity_score < 30 ? 'bg-green-500' :
                          result.toxicity_score < 70 ? 'bg-yellow-500' : 'bg-red-500'
                        }`}
                        style={{ width: `${result.toxicity_score}%` }}
                      ></div>
                    </div>
                  </div>
                </div>
                
                <div className="bg-white/20 rounded-xl p-6 text-center">
                  <h3 className="text-lg font-semibold text-white mb-4">Risk Level</h3>
                  <div className="text-6xl mb-2">{getRiskEmoji(result.risk_level)}</div>
                  <div className={`inline-block px-4 py-2 rounded-full font-bold text-lg ${getRiskColor(result.risk_level)}`}>
                    {result.risk_level} Risk
                  </div>
                </div>
              </div>

              {/* Humorous Verdict */}
              <div className="bg-gradient-to-r from-purple-500/20 to-pink-500/20 rounded-xl p-6 border border-purple-400/30">
                <h3 className="text-lg font-semibold text-white mb-3 flex items-center">
                  <span className="mr-2">🤖</span>
                  AI Roast Session
                </h3>
                <blockquote className="text-lg text-gray-200 italic leading-relaxed">
                  "{result.humorous_verdict}"
                </blockquote>
              </div>

              {/* Risk Breakdown */}
              {result.risk_factors && result.risk_factors.length > 0 && (
                <div className="mt-6 bg-white/10 rounded-xl p-6">
                  <h3 className="text-lg font-semibold text-white mb-4">🚩 Risk Factors Detected</h3>
                  <div className="grid md:grid-cols-2 gap-3">
                    {result.risk_factors.map((factor, index) => (
                      <div key={index} className="bg-red-500/20 rounded-lg p-3 border border-red-400/30">
                        <span className="text-red-300 text-sm">{factor}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* AI Breakdown Section */}
              {result.ai_breakdown && (
                <div className="mt-6 bg-white/10 rounded-xl border border-white/20">
                  <button
                    onClick={() => setShowBreakdown(!showBreakdown)}
                    className="w-full p-4 text-left flex items-center justify-between hover:bg-white/5 rounded-xl transition-colors"
                  >
                    <div className="flex items-center">
                      <span className="text-lg font-semibold text-white mr-2">🔍</span>
                      <h3 className="text-lg font-semibold text-white">Why This Score?</h3>
                      <span className="ml-2 text-sm text-gray-300">(AI Breakdown)</span>
                    </div>
                    <span className={`text-white transform transition-transform ${showBreakdown ? 'rotate-180' : ''}`}>
                      ▼
                    </span>
                  </button>
                  
                  {showBreakdown && (
                    <div className="px-4 pb-4">
                      <div className="grid md:grid-cols-2 gap-4">
                        {Object.entries(result.ai_breakdown).map(([key, data]) => (
                          <div key={key} className="bg-white/10 rounded-lg p-4">
                            <div className="flex justify-between items-center mb-2">
                              <span className="text-white font-medium">{data.label}</span>
                              <span className="text-white font-bold">{data.percentage}%</span>
                            </div>
                            <div className="w-full bg-gray-700 rounded-full h-2 mb-2">
                              <div 
                                className={`h-2 rounded-full transition-all duration-1000 ${
                                  data.percentage < 20 ? 'bg-green-500' :
                                  data.percentage < 50 ? 'bg-yellow-500' : 
                                  data.percentage < 80 ? 'bg-orange-500' : 'bg-red-500'
                                }`}
                                style={{ width: `${Math.max(data.percentage, 2)}%` }}
                              ></div>
                            </div>
                            <p className="text-xs text-gray-300">{data.description}</p>
                          </div>
                        ))}
                      </div>
                      <div className="mt-4 p-3 bg-blue-500/20 rounded-lg border border-blue-400/30">
                        <p className="text-sm text-blue-200">
                          <span className="font-semibold">🤖 How it works:</span> These scores come from Google's Perspective API, 
                          the same AI used by YouTube and major news sites to detect harmful content.
                        </p>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Social Share Buttons */}
              <div className="mt-6 bg-gradient-to-r from-green-500/20 to-blue-500/20 rounded-xl p-6 border border-green-400/30">
                <h3 className="text-lg font-semibold text-white mb-4 flex items-center">
                  <span className="mr-2">📢</span>
                  Share Your Results
                </h3>
                <div className="grid md:grid-cols-3 gap-3">
                  <button
                    onClick={shareToTwitter}
                    className="flex items-center justify-center px-4 py-3 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg transition-colors"
                  >
                    🐦 Tweet Results
                  </button>
                  <button
                    onClick={copyResultLink}
                    className="flex items-center justify-center px-4 py-3 bg-gray-600 hover:bg-gray-700 text-white font-medium rounded-lg transition-colors"
                  >
                    📋 Copy Results
                  </button>
                  <button
                    onClick={() => copyToClipboard(window.location.href)}
                    className="flex items-center justify-center px-4 py-3 bg-purple-600 hover:bg-purple-700 text-white font-medium rounded-lg transition-colors"
                  >
                    🔗 Copy Link
                  </button>
                </div>
              </div>

              {/* Action Button */}
              <div className="text-center mt-8">
                <button
                  onClick={() => {
                    setText('');
                    setResult(null);
                  }}
                  className="px-6 py-3 bg-gradient-to-r from-blue-500 to-cyan-500 hover:from-blue-600 hover:to-cyan-600 text-white font-bold rounded-xl transition-all duration-300 transform hover:scale-105"
                >
                  Analyze Another Post 🔄
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="text-center mt-16 text-gray-400 text-sm">
          <p>⚠️ For entertainment purposes only. We're not responsible for actual cancellations.</p>
          <p className="mt-2">Built with questionable humor and excessive caffeine ☕</p>
        </div>
      </div>
    </div>
  );
}

export default App;